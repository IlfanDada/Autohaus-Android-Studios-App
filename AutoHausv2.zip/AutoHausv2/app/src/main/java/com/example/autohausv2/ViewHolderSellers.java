package com.example.autohausv2;


import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;


public class ViewHolderSellers extends RecyclerView.Adapter<ViewHolderSellers.sellers> {

    Context context;
    ArrayList<Sellers> list_sellers;

    public ViewHolderSellers(Context c, ArrayList<Sellers> l) {
        context = c;
        list_sellers = l;
    }


    @NonNull
    @Override
    public sellers onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new sellers(LayoutInflater.from(context).inflate(R.layout.list_layout_sellers, parent, false));
    }


    @SuppressLint("RecyclerView")
    @Override
    public void onBindViewHolder(@NonNull sellers holder, final int position) {

        holder.txt_name.setText(list_sellers.get(position).getName());
        holder.txt_dealership_name.setText(list_sellers.get(position).getDealership());

        if(list_sellers.get(position).getIsopen().equals("true")){
            holder.txt_is_open.setText("Dealership opened");
        }
        else{
            holder.txt_is_open.setText("Dealership closed");
        }

        if(list_sellers.get(position).getImage().equals("")){

        }
        else{
            Picasso.get().load(list_sellers.get(position).getImage()).into(holder.image);
        }

        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent intent = new Intent(context, ActivityShowVehicles.class);
                intent.putExtra("uid", list_sellers.get(position).getUid());
                intent.putExtra("timestamp", list_sellers.get(position).getTimestamp());
                intent.putExtra("dealer", list_sellers.get(position).getDealership());
                intent.putExtra("address", list_sellers.get(position).getAddress());
                intent.putExtra("email", list_sellers.get(position).getEmail());
                intent.putExtra("number", list_sellers.get(position).getPhone());
                context.startActivity(intent);

                Controller.PutData(context,"dealership_name",list_sellers.get(position).getDealership());

            }
        });
    }

    @Override
    public int getItemCount() {
        return list_sellers.size();
    }

    class sellers extends RecyclerView.ViewHolder{

        TextView txt_name,txt_dealership_name,txt_is_open;
        ImageView image;
        CardView cardView;

        public sellers(View itemView){
            super(itemView);
            txt_name  = (TextView) itemView.findViewById(R.id.txt_name);
            txt_dealership_name  = (TextView) itemView.findViewById(R.id.txt_dealership_name);
            txt_is_open  = (TextView) itemView.findViewById(R.id.txt_isopen);
            image=(ImageView)itemView.findViewById(R.id.image_seller);
            cardView = (CardView)itemView.findViewById(R.id.cardview);
        }
    }

    public void filterList(ArrayList<Sellers> filteredList) {
        list_sellers = filteredList;
        notifyDataSetChanged();
    }
}


