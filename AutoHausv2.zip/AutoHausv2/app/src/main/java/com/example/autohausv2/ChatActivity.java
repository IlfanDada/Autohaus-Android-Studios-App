package com.example.autohausv2;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;


public class ChatActivity extends AppCompatActivity {


    //layout
    private Toolbar toolbar;
    private EditText edit_message;
    private ImageView bt_send,backArrow;
    private TextView txt_username;
    private RecyclerView recyclerView;
    private ArrayList<Message> messages;
    ChatAdapter chatAdapter;

    private FirebaseAuth firebaseAuth;
      private DatabaseReference messageReference;
     private DatabaseReference chatReference ;
    private ValueEventListener valueEventListenerMessage;

    //data receiver
    private String nameReceiver;
    private String idReceiver;

    //data sender
    private String idSender;
    private String nameSender;

    //constants
    private static final String TAG = "ChatActivity";
    LinearLayoutManager mLayoutManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        firebaseAuth=FirebaseAuth.getInstance();
        messageReference = FirebaseDatabase.getInstance().getReference().child("messages");
        chatReference = FirebaseDatabase.getInstance().getReference().child("chats");
        toolbar = findViewById(R.id.toolbar);
        txt_username=findViewById(R.id.userName);
        edit_message = findViewById(R.id.etMessage);
        bt_send = findViewById(R.id.send);
        backArrow = findViewById(R.id.backArrow);
        backArrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        recyclerView = findViewById(R.id.chatRecyclerView);
        mLayoutManager = new LinearLayoutManager(ChatActivity.this);
        recyclerView.setLayoutManager(mLayoutManager);
        //logged user data
        idSender = firebaseAuth.getUid();
        nameSender = Controller.GetData(ChatActivity.this,"name");
        Bundle bundle = getIntent().getExtras();

        if(bundle != null){
            nameReceiver = Controller.GetData(ChatActivity.this,"dealership_name") ;
            idReceiver = bundle.getString("uid");
            txt_username.setText(nameReceiver);
        }

        toolbar.setTitle(nameReceiver);
        setSupportActionBar(toolbar);

        messages = new ArrayList<>();
        chatAdapter = new ChatAdapter(ChatActivity.this, messages);
        recyclerView.setAdapter(chatAdapter);


        valueEventListenerMessage = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                messages.clear();

                for(DataSnapshot data: dataSnapshot.getChildren()){
                    Message message = data.getValue(Message.class);
                    messages.add(message);
                }

                chatAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        };

        messageReference.child(idSender).child(idReceiver).addValueEventListener(valueEventListenerMessage);
        bt_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String messageText = edit_message.getText().toString();

                if(messageText.isEmpty()){

                }else{
                    Message message = new Message();
                    message.setUserId(idSender);
                    message.setMessage(messageText);

                    //saving message for sender
                    Boolean messageSenderReturn = saveMessage(idSender, idReceiver, message);
                    if(!messageSenderReturn){
                        Toast.makeText(ChatActivity.this, "Problem saving the message, please try again!", Toast.LENGTH_LONG).show();
                    }else{
                        Log.i(TAG, "messageReturn: success");
                        Boolean messageReceiverReturn = saveMessage(idReceiver, idSender, message);
                        if(!messageReceiverReturn){
                            Log.i(TAG, "messageReceiverReturn: error sending the message");
                            Toast.makeText(ChatActivity.this, "Problem sending the message, please try again!", Toast.LENGTH_LONG).show();
                        }
                    }

                    Chat chat = new Chat();
                    chat.setIdUser(idReceiver);
                    chat.setName(nameReceiver);
                    chat.setMessage(messageText);

                    Boolean chatSenderReturn = saveChat(idSender, idReceiver, chat);
                    if(!chatSenderReturn){
                        Log.i(TAG, "chatSenderReturn: error saving the chat");
                        Toast.makeText(ChatActivity.this, "Problem saving the chat, please try again!", Toast.LENGTH_LONG).show();
                    }else{
                        Log.i(TAG, "chatReturn: success");
                        chat = new Chat();
                        chat.setIdUser(idSender);
                        chat.setName(nameSender);
                        chat.setMessage(messageText);
                        Boolean chatReceiverReturn = saveChat(idReceiver, idSender, chat);

                        if(!chatReceiverReturn){
                            Log.i(TAG, "chatReceiverReturn: error saving the chat for receiver");
                            Toast.makeText(ChatActivity.this, "Problem saving the chat for receiver, please try again!", Toast.LENGTH_LONG).show();
                        }
                    }

                    edit_message.setText("");
                }
            }
        });
    }

    private boolean saveMessage(String idSender, String idReceiver, Message message){
        try{
            messageReference.child(idSender).child(idReceiver).push().setValue(message);
           return true;
        }catch (Exception e){
            e.printStackTrace();
            return false;
        }
    }

    private boolean saveChat(String idSender, String idReceiver, Chat chat){
        try{
            chatReference.child(idSender).child(idReceiver).setValue(chat);

            return true;
        }catch (Exception e){
            e.printStackTrace();
            return false;
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        messageReference.removeEventListener(valueEventListenerMessage);
        Log.i(TAG, "ValueEventListener: onStop");
    }

}

