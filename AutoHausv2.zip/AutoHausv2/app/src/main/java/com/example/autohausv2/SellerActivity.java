package com.example.autohausv2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class SellerActivity extends AppCompatActivity {

    private TextView nameTitle, dealerNameTitle,emailTitle;
    private ImageView profileIV;
    private ImageButton logoutBtn, editProBtn, addVehicleBtn,chatBtn;
    private RelativeLayout vehicleRL;
    private EditText txt_search;
    DatabaseReference db_ref;
    ProgressBar progressBar;
    ArrayList<Vehicles> list_vehicles=new ArrayList<>();
    ViewHolderVehiclesSeller viewHolderVehicles;
    private RecyclerView recyclerView;
    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_seller);

        nameTitle = findViewById(R.id.nameTitle);
        logoutBtn = findViewById(R.id.logoutBtn);
        editProBtn = findViewById(R.id.editProBtn);
        addVehicleBtn = findViewById(R.id.addVehicleBtn);
        profileIV = findViewById(R.id.profileIV);
        dealerNameTitle = findViewById(R.id.dealerNameTitle);
        emailTitle = findViewById(R.id.emailTitle);

        vehicleRL = findViewById(R.id.vehicleRL);
        db_ref=FirebaseDatabase.getInstance().getReference().child("Users");
        recyclerView =findViewById(R.id.recyclerview);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        progressBar=findViewById(R.id.progress_circular);

        firebaseAuth = FirebaseAuth.getInstance();
        checkUser();
        showVehicleUI();
        chatBtn=findViewById(R.id.btn_chat);
        chatBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SellerActivity.this,ActivityChatUsers.class));
            }
        });
        txt_search=findViewById(R.id.txt_search);
        txt_search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

                try{
                    filter(s.toString());
                }
                catch (Exception e){

                }

            }
        });
        logoutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                firebaseAuth.signOut();
                checkUser();
            }
        });

        editProBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SellerActivity.this, ProfileSellerCrudActivity.class));
                finish();
            }
        });

        addVehicleBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SellerActivity.this, AddVehicleActivity.class));
                finish();
            }
        });


    }

    private void showVehicleUI() {

    }

    private void checkUser() {
        FirebaseUser user = firebaseAuth.getCurrentUser();

        if (user == null) {
            startActivity(new Intent(SellerActivity.this, LoginActivity.class));
            finish();
        }
        else {
            LoadMyInformation();
        }
    }

    private void LoadMyInformation() {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Users");
        reference.orderByChild("uid").equalTo(firebaseAuth.getUid())
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot ds: snapshot.getChildren()){
                            String name = ""+ds.child("name").getValue();
                            String accountType = ""+ds.child("accountType").getValue();
                            String email = ""+ds.child("email").getValue();
                            String dealershipName = ""+ds.child("dealershipName").getValue();
                            String profileImage = ""+ds.child("profileImage").getValue();

                            nameTitle.setText(name);
                            emailTitle.setText(email);
                            dealerNameTitle.setText(dealershipName);
                            fetch_vehicles(firebaseAuth.getUid());

                            try {
                                Picasso.get().load(profileImage).placeholder(R.drawable.ic_car).into(profileIV);
                            } catch (Exception e) {
                                profileIV.setImageResource(R.drawable.ic_car);
                            }


                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }

    public void fetch_vehicles(String uid){
        db_ref.child(uid).child("Vehicles").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                list_vehicles.clear();
                for (DataSnapshot postSnapshot : snapshot.getChildren()) {
                    String key=postSnapshot.getKey();
                    String vehicleName = postSnapshot.child("vehicleName").getValue(String.class);
                    String vehicleDescription = postSnapshot.child("vehicleDescription").getValue(String.class);
                    String vehicleCategory = postSnapshot.child("vehicleCategory").getValue(String.class);
                    String mileage = postSnapshot.child("mileage").getValue(String.class);
                    String vehicleReg = postSnapshot.child("vehicleReg").getValue(String.class);
                    String vehiclePrice = postSnapshot.child("vehiclePrice").getValue(String.class);
                    String vehicleSeats = postSnapshot.child("vehicleSeats").getValue(String.class);
                    String vehicleType = postSnapshot.child("vehicleType").getValue(String.class);
                    String fuelType = postSnapshot.child("fuelType").getValue(String.class);
                    String vehicleManufacturer = postSnapshot.child("vehicleManufacturer").getValue(String.class);
                    String vehicleIcon = postSnapshot.child("vehicleIcon").getValue(String.class);
                    String timestamp = postSnapshot.child("timestamp").getValue(String.class);
                    String uid = postSnapshot.child("uid").getValue(String.class);

                    list_vehicles.add(new Vehicles(key,vehicleName,vehicleDescription,vehicleCategory,mileage,vehicleReg,vehiclePrice,vehicleSeats,vehicleType,fuelType,vehicleManufacturer,vehicleIcon,timestamp,uid));

                }
                if(list_vehicles.size()>0){
                    progressBar.setVisibility(View.GONE);
                    viewHolderVehicles=new ViewHolderVehiclesSeller(SellerActivity.this,list_vehicles);
                    recyclerView.setAdapter(viewHolderVehicles);

                }
                else{
                    progressBar.setVisibility(View.GONE);
                 //   Toast.makeText(SellerActivity.this,"Something went wrong",Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                progressBar.setVisibility(View.GONE);
            }
        });
    }


    private void filter(String text) {
        ArrayList<Vehicles> filteredList = new ArrayList<>();
        for (Vehicles item : list_vehicles) {
            if (item.getCategory().toLowerCase().contains(text.toLowerCase())) {
                filteredList.add(item);
            }
        }
        viewHolderVehicles.filterList(filteredList);
    }
}