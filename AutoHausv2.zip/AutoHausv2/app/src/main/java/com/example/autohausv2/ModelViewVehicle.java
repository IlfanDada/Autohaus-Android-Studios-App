package com.example.autohausv2;

public class ModelViewVehicle {
    private String vehicleId,
            vehicleDescription,
            vehicleCategory,
            mileage,
            vehicleReg,
            vehiclePrice,
            vehicleSeats ,
            vehicleType,
            fuelType,
            vehicleManufacturer,
            vehicleIcon,
            timestamp,
            uid;

    public ModelViewVehicle(){

    }

    public ModelViewVehicle(String vehicleId,
                            String vehicleDescription,
                            String vehicleCategory,
                            String mileage,
                            String vehicleReg,
                            String vehiclePrice,
                            String vehicleSeats,
                            String vehicleType,
                            String fuelType,
                            String vehicleManufacturer,
                            String vehicleIcon,
                            String timestamp,
                            String uid) {

        this.vehicleId = vehicleId;
        this.vehicleDescription = vehicleDescription;
        this.vehicleCategory = vehicleCategory;
        this.mileage = mileage;
        this.vehicleReg = vehicleReg;
        this.vehiclePrice = vehiclePrice;
        this.vehicleSeats = vehicleSeats;
        this.vehicleType = vehicleType;
        this.fuelType = fuelType;
        this.vehicleManufacturer = vehicleManufacturer;
        this.vehicleIcon = vehicleIcon;
        this.timestamp = timestamp;
        this.uid = uid;
    }

    public String getVehicleId() {
        return vehicleId;
    }

    public void setVehicleId(String vehicleId) {
        this.vehicleId = vehicleId;
    }

    public String getVehicleDescription() {
        return vehicleDescription;
    }

    public void setVehicleDescription(String vehicleDescription) {
        this.vehicleDescription = vehicleDescription;
    }

    public String getVehicleCategory() {
        return vehicleCategory;
    }

    public void setVehicleCategory(String vehicleCategory) {
        this.vehicleCategory = vehicleCategory;
    }

    public String getMileage() {
        return mileage;
    }

    public void setMileage(String mileage) {
        this.mileage = mileage;
    }

    public String getVehicleReg() {
        return vehicleReg;
    }

    public void setVehicleReg(String vehicleReg) {
        this.vehicleReg = vehicleReg;
    }

    public String getVehiclePrice() {
        return vehiclePrice;
    }

    public void setVehiclePrice(String vehiclePrice) {
        this.vehiclePrice = vehiclePrice;
    }

    public String getVehicleSeats() {
        return vehicleSeats;
    }

    public void setVehicleSeats(String vehicleSeats) {
        this.vehicleSeats = vehicleSeats;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public String getFuelType() {
        return fuelType;
    }

    public void setFuelType(String fuelType) {
        this.fuelType = fuelType;
    }

    public String getVehicleManufacturer() {
        return vehicleManufacturer;
    }

    public void setVehicleManufacturer(String vehicleManufacturer) {
        this.vehicleManufacturer = vehicleManufacturer;
    }

    public String getVehicleIcon() {
        return vehicleIcon;
    }

    public void setVehicleIcon(String vehicleIcon) {
        this.vehicleIcon = vehicleIcon;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }
}
