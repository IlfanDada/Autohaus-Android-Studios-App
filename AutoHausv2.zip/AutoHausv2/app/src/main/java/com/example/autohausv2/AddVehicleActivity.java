package com.example.autohausv2;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.util.HashMap;

public class AddVehicleActivity extends AppCompatActivity {

    private ImageView vehicleIconIv;
    private EditText vehicleNameInput,
            vehicleDescriptionInput,
            vehicleCategoryInput,
            mileageInput,
            vehicleRegInput,
            vehiclePriceInput,
            fuelTypeInput,
            vehicleTypeInput,
            vehicleManufacturerInput,
            vehicleSeatsInput;

    private Button addListBtn, backBtn;

    public static final int CAMERA_REQUEST_CODE = 200;
    public static final int STORAGE_REQUEST_CODE = 300;
    public static final int IMAGE_PICK_GALLERY_CODE = 400;
    public static final int IMAGE_PICK_CAMERA_CODE = 500;

    private String[] cameraPermissions;
    private String[] storagePermissions;
    private Uri image_uri;

    private  FirebaseAuth firebaseAuth;
    String vehicle_icon,key;
    private ProgressDialog progressDialog;
    private boolean flag_update=false;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_add_vehicle);


        addListBtn = findViewById(R.id.addListBtn);
        backBtn = findViewById(R.id.backBtn);


        vehicleIconIv = findViewById(R.id.vehicleIconIv);
        vehicleNameInput = findViewById(R.id.vehicleNameInput);
        vehicleDescriptionInput = findViewById(R.id.vehicleDescriptionInput);
        vehicleCategoryInput = findViewById(R.id.vehicleCategoryInput);
        vehicleRegInput = findViewById(R.id.vehicleRegInput);
        mileageInput = findViewById(R.id.mileageInput);
        vehiclePriceInput = findViewById(R.id.vehiclePriceInput);
        vehicleSeatsInput = findViewById(R.id.vehicleSeatsInput);
        fuelTypeInput = findViewById(R.id.fuelTypeInput);
        vehicleTypeInput = findViewById(R.id.vehicleTypeInput);
        vehicleManufacturerInput = findViewById(R.id.vehicleManufacturerInput);

        firebaseAuth = FirebaseAuth.getInstance();

        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Please wait");
        progressDialog.setCanceledOnTouchOutside(false);

        cameraPermissions = new String[]{Manifest.permission.CAMERA,Manifest.permission.WRITE_EXTERNAL_STORAGE};
        storagePermissions = new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE};


        vehicleIconIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showImagePickDialog();
            }
        });

        vehicleCategoryInput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                categoryDialog();
            }
        });

        vehicleTypeInput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                categoryDialog2();
            }
        });

        fuelTypeInput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                categoryDialog3();
            }
        });

        vehicleManufacturerInput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                categoryDialog4();
            }
        });

        addListBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(addListBtn.getText().toString().equals("Update Info")){
                    inputData();
                }
                else{
                    inputData();
                }

            }
        });

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(AddVehicleActivity.this,SellerActivity.class));
            }
        });
        Bundle extras = getIntent().getExtras();
        if(extras != null){
            vehicleNameInput.setText(extras.getString("name"));
            vehicleDescriptionInput.setText(extras.getString("description"));
            vehicleCategoryInput.setText(extras.getString("category"));
            vehicleManufacturerInput.setText(extras.getString("manufecturer"));
            vehicleTypeInput.setText(extras.getString("vtype"));
            fuelTypeInput.setText(extras.getString("ftype"));
            mileageInput.setText(extras.getString("mileage"));
            vehicleRegInput.setText(extras.getString("reg"));
            vehiclePriceInput.setText(extras.getString("price"));
            vehicleSeatsInput.setText(extras.getString("seats"));
            key=extras.getString("key");
            vehicle_icon=extras.getString("icon");
            if(vehicle_icon.equals("")){
            }
            else{
                Picasso.get().load(vehicle_icon).into(vehicleIconIv);
            }

            addListBtn.setText("Update Info");
            flag_update=true;
        }


    }


    private String vehicleName,
            vehicleDescription,
            vehicleCategory,
            mileage,
            vehicleReg,
            vehiclePrice,
            vehicleSeats,
            vehicleType,
            fuelType,
            vehicleManufacturer;


    private void inputData() {

        vehicleName = vehicleNameInput.getText().toString().trim();
        vehicleDescription = vehicleDescriptionInput.getText().toString().trim();
        vehicleCategory = vehicleCategoryInput.getText().toString().trim();
        mileage = mileageInput.getText().toString().trim();
        vehicleReg = vehicleRegInput.getText().toString().trim();
        vehiclePrice = vehiclePriceInput.getText().toString().trim();
        vehicleSeats = vehicleSeatsInput.getText().toString().trim();
        vehicleType = vehicleTypeInput.getText().toString().trim();
        fuelType = fuelTypeInput.getText().toString().trim();
        vehicleManufacturer = vehicleManufacturerInput.getText().toString().trim();


        if (TextUtils.isEmpty(vehicleName)){
            Toast.makeText(this, "Vehicle name required", Toast.LENGTH_SHORT).show();
            return;
        }
        if (TextUtils.isEmpty(vehicleDescription)){
            Toast.makeText(this, "Tell us about your car!", Toast.LENGTH_SHORT).show();
            return;
        }
        if (TextUtils.isEmpty(mileage)){
            Toast.makeText(this, "Vehicle mileage is empty", Toast.LENGTH_SHORT).show();
            return;
        }
        if (mileage.length()<0){
            Toast.makeText(this, "Please check mileage field", Toast.LENGTH_SHORT).show();
            return;
        }

        if (TextUtils.isEmpty(vehicleReg)){
            Toast.makeText(this, "Please check vehicle Reg", Toast.LENGTH_SHORT).show();
            return;
        }
        if (TextUtils.isEmpty(vehiclePrice)){
            Toast.makeText(this, "Vehicle price is empty", Toast.LENGTH_SHORT).show();
            return;
        }
        if (TextUtils.isEmpty(vehicleSeats)){
            Toast.makeText(this, "Please check seats field", Toast.LENGTH_SHORT).show();
            return;
        }

        if (vehicleSeats.length()>60){
            Toast.makeText(this, "Please check seats field", Toast.LENGTH_SHORT).show();
            return;
        }

        if (TextUtils.isEmpty(vehicleType)){
            Toast.makeText(this, "Please check vehicle type", Toast.LENGTH_SHORT).show();
            return;
        }

        if (TextUtils.isEmpty(fuelType)){
            Toast.makeText(this, "Please check fuel type", Toast.LENGTH_SHORT).show();
            return;
        }
        if (TextUtils.isEmpty(vehicleManufacturer)){
            Toast.makeText(this, "please check manufacturer", Toast.LENGTH_SHORT).show();
            return;
        }

        else {
            addList();
        }


    }

    private void addList() {
        progressDialog.setMessage("Adding your listing ");
        progressDialog.show();

        String timestamp = ""+System.currentTimeMillis();
        if(image_uri == null){
            HashMap<String, Object> hashMap = new HashMap<>();
            hashMap.put("vehicleId",""+timestamp);
            hashMap.put("vehicleName",""+vehicleName);
            hashMap.put("vehicleDescription",""+vehicleDescription);
            hashMap.put("vehicleCategory",""+vehicleCategory);
            hashMap.put("mileage",""+mileage);
            hashMap.put("vehicleReg",""+vehicleReg);
            hashMap.put("vehiclePrice",""+vehiclePrice);
            hashMap.put("vehicleSeats",""+vehicleSeats);
            hashMap.put("vehicleType",""+vehicleType);
            hashMap.put("fuelType",""+fuelType);
            hashMap.put("vehicleManufacturer",""+vehicleManufacturer);
            if(flag_update){
                hashMap.put("vehicleIcon",vehicle_icon);
            }
            else{
                hashMap.put("vehicleIcon","");
            }
            hashMap.put("timestamp",""+timestamp);
            hashMap.put("uid",""+firebaseAuth.getUid());
            DatabaseReference databaseReference;
            if(flag_update){
                Toast.makeText(AddVehicleActivity.this,"Update "+key,Toast.LENGTH_LONG).show();
                 databaseReference = FirebaseDatabase.getInstance().getReference("Users").child(firebaseAuth.getUid()).child("Vehicles").child(key);
            }
            else{
                 databaseReference = FirebaseDatabase.getInstance().getReference("Users").child(firebaseAuth.getUid()).child("Vehicles").child(timestamp);
            }



            databaseReference.setValue(hashMap)
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            progressDialog.dismiss();
                            Toast.makeText(AddVehicleActivity.this, "Hooray! Vehicle Listed", Toast.LENGTH_SHORT).show();
                            clearData();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            progressDialog.dismiss();
                            Toast.makeText(AddVehicleActivity.this, ""+e.getMessage(), Toast.LENGTH_SHORT).show();

                        }
                    });
        }
        else{

            String filePathAndName = "vehicle_images/"+""+timestamp;

            StorageReference storageReference = FirebaseStorage.getInstance().getReference(filePathAndName);
            storageReference.putFile(image_uri)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            progressDialog.dismiss();

                            Task<Uri> uriTask = taskSnapshot.getStorage().getDownloadUrl();
                            while (!uriTask.isSuccessful());
                            Uri downloadImageUri = uriTask.getResult();

                            if (uriTask.isSuccessful()){

                                HashMap<String, Object> hashMap = new HashMap<>();
                                hashMap.put("vehicleId",""+timestamp);
                                hashMap.put("vehicleName",""+vehicleName);
                                hashMap.put("vehicleDescription",""+vehicleDescription);
                                hashMap.put("vehicleCategory",""+vehicleCategory);
                                hashMap.put("mileage",""+mileage);
                                hashMap.put("vehicleReg",""+vehicleReg);
                                hashMap.put("vehiclePrice",""+vehiclePrice);
                                hashMap.put("vehicleSeats",""+vehicleSeats);
                                hashMap.put("vehicleType",""+vehicleType);
                                hashMap.put("fuelType",""+fuelType);
                                hashMap.put("vehicleManufacturer",""+vehicleManufacturer);
                                hashMap.put("vehicleIcon",""+downloadImageUri);
                                hashMap.put("timestamp",""+timestamp);
                                hashMap.put("uid",""+firebaseAuth.getUid());
                                DatabaseReference databaseReference;
                                if(flag_update){
                                    databaseReference = FirebaseDatabase.getInstance().getReference("Users").child(firebaseAuth.getUid()).child("Vehicles").child(key);
                                }
                                else{
                                    databaseReference = FirebaseDatabase.getInstance().getReference("Users").child(firebaseAuth.getUid()).child("Vehicles").child(timestamp);
                                }

                                databaseReference.setValue(hashMap).addOnSuccessListener(new OnSuccessListener<Void>() {
                                            @Override
                                            public void onSuccess(Void aVoid) {
                                                progressDialog.dismiss();
                                                Toast.makeText(AddVehicleActivity.this, "Hooray! Vehicle Listed", Toast.LENGTH_SHORT).show();
                                                clearData();
                                            }
                                        })
                                        .addOnFailureListener(new OnFailureListener() {
                                            @Override
                                            public void onFailure(@NonNull Exception e) {
                                                progressDialog.dismiss();
                                                Toast.makeText(AddVehicleActivity.this, ""+e.getMessage(), Toast.LENGTH_SHORT).show();

                                            }
                                        });
                            }

                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            progressDialog.dismiss();
                            Toast.makeText(AddVehicleActivity.this, ""+e.getMessage(), Toast.LENGTH_SHORT).show();

                        }
                    });


        }

    }

    private void clearData(){

        vehicleNameInput.setText("");
        vehicleDescriptionInput.setText("");
        vehicleCategoryInput.setText("");
        mileageInput.setText("");
        vehicleRegInput.setText("");
        vehiclePriceInput.setText("");
        fuelTypeInput.setText("");
        vehicleTypeInput.setText("");
        vehicleManufacturerInput.setText("");
        vehicleSeatsInput.setText("");
        vehicleIconIv.setImageResource(R.drawable.ic_add_car_pic);
        image_uri = null;
    }

    private void categoryDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Vehicle Category")
                .setItems(ConstraintsArrays.vehicleCategories, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String category = ConstraintsArrays.vehicleCategories[which];

                        vehicleCategoryInput.setText(category);
                    }
                })
                .show();
    }

    private void categoryDialog2() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("What type of gearbox does your vehicle have?")
                .setItems(ConstraintsArrays.vehicleTypes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String typeCategory = ConstraintsArrays.vehicleTypes[which];

                        vehicleTypeInput.setText(typeCategory);
                    }
                })
                .show();
    }
    private void categoryDialog3() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("What type of fuel does your vehicle use?")
                .setItems(ConstraintsArrays.fuelTypes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String typeCategory = ConstraintsArrays.fuelTypes[which];
                        fuelTypeInput.setText(typeCategory);
                    }
                })
                .show();
    }
    private void categoryDialog4() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("What make is your vehicle?")
                .setItems(ConstraintsArrays.manufacturers, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String typeCategory = ConstraintsArrays.manufacturers[which];
                        vehicleManufacturerInput.setText(typeCategory);
                    }
                })
                .show();
    }





    private void showImagePickDialog() {

        String[] options = {"Camera","Gallery"};
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Pick Image").setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (which == 0){
                    if (checkCameraPermission())
                    {
                        pickFromCamera();
                    }
                    else {
                        requestCameraPermission();
                    }
                }
                else
                {
                    if ( checkStoragePermission() )
                    {
                        pickFromGallery();
                    }
                    else {
                        requestStoragePermission();
                    }
                }
            }
        })
                .show();

    }

    private void pickFromGallery() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        startActivityForResult(intent, IMAGE_PICK_GALLERY_CODE);
    }

    private void pickFromCamera() {
        ContentValues contentValues = new ContentValues();
        contentValues.put(MediaStore.Images.Media.TITLE, "Temp_Image");
        contentValues.put(MediaStore.Images.Media.DESCRIPTION, "Temp_Image Description");

        image_uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues);

        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        intent.putExtra (MediaStore.EXTRA_OUTPUT, image_uri);
        startActivityForResult(intent, IMAGE_PICK_GALLERY_CODE);
    }

    private boolean checkStoragePermission() {
        boolean result = ContextCompat.checkSelfPermission(this,Manifest.permission.WRITE_EXTERNAL_STORAGE) == (PackageManager.PERMISSION_GRANTED);
        return result;
    }

    private void requestStoragePermission() {
        ActivityCompat.requestPermissions(this,storagePermissions,STORAGE_REQUEST_CODE);
    }

    private boolean checkCameraPermission() {
        boolean result = ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA) == (PackageManager.PERMISSION_GRANTED);
        boolean result1 = ContextCompat.checkSelfPermission(this,Manifest.permission.WRITE_EXTERNAL_STORAGE) == (PackageManager.PERMISSION_GRANTED);
        return result && result1;
    }

    private void requestCameraPermission() {
        ActivityCompat.requestPermissions(this,cameraPermissions,CAMERA_REQUEST_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode){
            case CAMERA_REQUEST_CODE:{
                if (grantResults.length>0){
                    boolean cameraAccepted = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    boolean storageAccepted = grantResults[1] == PackageManager.PERMISSION_GRANTED;
                    if (cameraAccepted && storageAccepted ){
                        pickFromCamera();
                    }
                    else {
                        Toast.makeText(this, "Camera Permission Required", Toast.LENGTH_SHORT).show();

                    }
                }
            }
            break;
            case STORAGE_REQUEST_CODE:{
                if (grantResults.length>0){
                    boolean storageAccepted = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    if (storageAccepted ){
                        pickFromGallery();
                    }
                    else {
                        Toast.makeText(this, "Storage Permission Required", Toast.LENGTH_SHORT).show();
                    }
                }
            }
            break;

        }

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        if (resultCode == RESULT_OK) {
            if (requestCode == IMAGE_PICK_GALLERY_CODE){
                image_uri = data.getData();

                vehicleIconIv.setImageURI(image_uri);
            }

            else if (requestCode == IMAGE_PICK_CAMERA_CODE){
                vehicleIconIv.setImageURI(image_uri);
            }

        }

        super.onActivityResult(requestCode, resultCode, data);
    }


}

