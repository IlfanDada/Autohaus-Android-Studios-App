package com.example.autohausv2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class ActivityShowVehicles extends AppCompatActivity {

    private EditText txt_search;
    DatabaseReference db_ref;
    ProgressBar progressBar;
    ArrayList<Vehicles> list_vehicles=new ArrayList<>();
    ViewHolderVehicles viewHolderVehicles;
    private RecyclerView recyclerView;
   private TextView txt_title;
   private String address,email,number;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_user);
        db_ref=FirebaseDatabase.getInstance().getReference().child("Users");
        recyclerView =findViewById(R.id.recyclerview);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        progressBar=findViewById(R.id.progress_circular);
        txt_title=findViewById(R.id.nameTitle);
        txt_title.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(ActivityShowVehicles.this)
                        .setTitle(txt_title.getText().toString())
                        .setMessage("Address "+address+"\n"+"Email "+email+"\n"+"Number "+number)
                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        })
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .show();
            }
        });
        txt_search=findViewById(R.id.txt_search);
        txt_search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
              try {
                  filter(s.toString());
              }
               catch (Exception e){

               }
            }
        });

        Bundle extras = getIntent().getExtras();
        if(extras != null){
            String uid = extras.getString("uid");
            String dealer = extras.getString("dealer");
            txt_title.setText(dealer);
            address=extras.getString("address");
            email=extras.getString("email");
            number=extras.getString("number");

            fetch_vehicles(uid);
        }


    }





    public void fetch_vehicles(String uid){
        db_ref.child(uid).child("Vehicles").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                list_vehicles.clear();
                for (DataSnapshot postSnapshot : snapshot.getChildren()) {
                        String key=postSnapshot.getKey();
                        String vehicleName = postSnapshot.child("vehicleName").getValue(String.class);
                        String vehicleDescription = postSnapshot.child("vehicleDescription").getValue(String.class);
                        String vehicleCategory = postSnapshot.child("vehicleCategory").getValue(String.class);
                        String mileage = postSnapshot.child("mileage").getValue(String.class);
                        String vehicleReg = postSnapshot.child("vehicleReg").getValue(String.class);
                        String vehiclePrice = postSnapshot.child("vehiclePrice").getValue(String.class);
                        String vehicleSeats = postSnapshot.child("vehicleSeats").getValue(String.class);
                        String vehicleType = postSnapshot.child("vehicleType").getValue(String.class);
                        String fuelType = postSnapshot.child("fuelType").getValue(String.class);
                        String vehicleManufacturer = postSnapshot.child("vehicleManufacturer").getValue(String.class);
                        String vehicleIcon = postSnapshot.child("vehicleIcon").getValue(String.class);
                        String timestamp = postSnapshot.child("timestamp").getValue(String.class);
                        String uid = postSnapshot.child("uid").getValue(String.class);


                        list_vehicles.add(new Vehicles(key,vehicleName,vehicleDescription,vehicleCategory,mileage,vehicleReg,vehiclePrice,vehicleSeats,vehicleType,fuelType,vehicleManufacturer,vehicleIcon,timestamp,uid));

                }
                if(list_vehicles.size()>0){
                    progressBar.setVisibility(View.GONE);
                    viewHolderVehicles=new ViewHolderVehicles(ActivityShowVehicles.this,list_vehicles);
                    recyclerView.setAdapter(viewHolderVehicles);

                }
                else{
                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(ActivityShowVehicles.this,"Something went wrong",Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            progressBar.setVisibility(View.GONE);
            }
        });
    }


    private void filter(String text) {
        ArrayList<Vehicles> filteredList = new ArrayList<>();
        for (Vehicles item : list_vehicles) {
            if (item.getCategory().toLowerCase().contains(text.toLowerCase())) {
                filteredList.add(item);
            }
        }
        viewHolderVehicles.filterList(filteredList);
    }
}