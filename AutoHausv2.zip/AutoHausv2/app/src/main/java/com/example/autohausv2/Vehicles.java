package com.example.autohausv2;

public class Vehicles {

    String key,name,description,category,mileage,reg,price,seats,vtype,ftype,manufacturer,icon,timesamp,uid;

    public Vehicles(String key,String name, String description, String category, String mileage, String reg, String price, String seats, String vtype, String ftype, String manufacturer, String icon, String timesamp, String uid) {
        this.key = key;
        this.name = name;
        this.description = description;
        this.category = category;
        this.mileage = mileage;
        this.reg = reg;
        this.price = price;
        this.seats = seats;
        this.vtype = vtype;
        this.ftype = ftype;
        this.manufacturer = manufacturer;
        this.icon = icon;
        this.timesamp = timesamp;
        this.uid = uid;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getMileage() {
        return mileage;
    }

    public void setMileage(String mileage) {
        this.mileage = mileage;
    }

    public String getReg() {
        return reg;
    }

    public void setReg(String reg) {
        this.reg = reg;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getSeats() {
        return seats;
    }

    public void setSeats(String seats) {
        this.seats = seats;
    }

    public String getVtype() {
        return vtype;
    }

    public void setVtype(String vtype) {
        this.vtype = vtype;
    }

    public String getFtype() {
        return ftype;
    }

    public void setFtype(String ftype) {
        this.ftype = ftype;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getTimesamp() {
        return timesamp;
    }

    public void setTimesamp(String timesamp) {
        this.timesamp = timesamp;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }
}
