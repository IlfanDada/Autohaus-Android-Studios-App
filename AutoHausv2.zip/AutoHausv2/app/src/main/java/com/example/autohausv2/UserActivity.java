package com.example.autohausv2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class UserActivity extends AppCompatActivity {

    private TextView nameTitle;
    private ImageButton logoutBtn,editProBtn,chatBtn;
    ImageView btn_bookmark;
    private FirebaseAuth firebaseAuth;
    private EditText txt_search;
    DatabaseReference db_ref;
    ProgressBar progressBar;
    ArrayList<Sellers> list_sellers=new ArrayList<>();
    ArrayList<Vehicles> list_bookmarks=new ArrayList<>();
    ViewHolderSellers viewHolderSellers;
    RecyclerView recyclerView;
    private Dialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_user);
        db_ref=FirebaseDatabase.getInstance().getReference().child("Users");
        recyclerView =findViewById(R.id.recyclerview);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        progressBar=findViewById(R.id.progress_circular);
        nameTitle = findViewById(R.id.nameTitle);
        logoutBtn = findViewById(R.id.logoutBtn);
        editProBtn = findViewById(R.id.editProBtn);
        btn_bookmark=findViewById(R.id.btn_bookmark);
        btn_bookmark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fetch_bookmarks();
            }
        });
        chatBtn=findViewById(R.id.btn_chat);
        chatBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               startActivity(new Intent(UserActivity.this,ActivityChatUsers.class));
            }
        });
        txt_search=findViewById(R.id.txt_search);
        txt_search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

                try{
                    filter(s.toString());
                }
                catch (Exception e){

                }

            }
        });

        firebaseAuth = FirebaseAuth.getInstance();
        checkUser();
        fetch_sellers();
        logoutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                firebaseAuth.signOut();
                checkUser();
            }
        });


        editProBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(UserActivity.this, ProfileUserCrudActivity.class));
                finish();
            }
        });
    }

    private void checkUser() {
        FirebaseUser user = firebaseAuth.getCurrentUser();

        if (user == null) {
            startActivity(new Intent(UserActivity.this, LoginActivity.class));
            finish();
        }
        else {
            LoadMyInformation();
        }
    }

    private void LoadMyInformation() {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Users");
        reference.orderByChild("uid").equalTo(firebaseAuth.getUid())
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot ds: snapshot.getChildren()){
                            String name = ""+ds.child("name").getValue();
                            String accountType = ""+ds.child("accountType").getValue();

                            nameTitle.setText(name);


                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }

    public void fetch_sellers(){
        db_ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
             list_sellers.clear();

                for (DataSnapshot postSnapshot : snapshot.getChildren()) {

                    if(postSnapshot.child("accountType").getValue(String.class).equals("Seller")){

                        String uid = postSnapshot.child("uid").getValue(String.class);
                        String name = postSnapshot.child("name").getValue(String.class);
                        String email = postSnapshot.child("email").getValue(String.class);
                        String phone = postSnapshot.child("phone").getValue(String.class);
                        String image = postSnapshot.child("profileImage").getValue(String.class);
                        String dealership = postSnapshot.child("dealershipName").getValue(String.class);
                        String timestamp = postSnapshot.child("timestamp").getValue(String.class);
                        String latitude = postSnapshot.child("latitude").getValue(String.class);
                        String longitude = postSnapshot.child("longitude").getValue(String.class);
                        String city = postSnapshot.child("city").getValue(String.class);
                        String state = postSnapshot.child("state").getValue(String.class);
                        String country = postSnapshot.child("country").getValue(String.class);
                        String address = postSnapshot.child("address").getValue(String.class);
                        String online = postSnapshot.child("online").getValue(String.class);
                        String ispen = postSnapshot.child("dealershipOpen").getValue(String.class);

                        list_sellers.add(new Sellers(uid,name,email,phone,image,dealership,timestamp,latitude,longitude,city,state,country,address,online,ispen));
                    }
                }
                if(list_sellers.size()>0){
                  progressBar.setVisibility(View.GONE);
                  viewHolderSellers=new ViewHolderSellers(UserActivity.this,list_sellers);
                    recyclerView.setAdapter(viewHolderSellers);

                }
                else{
                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(UserActivity.this,"Something went wrong",Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }





    private void filter(String text) {
        ArrayList<Sellers> filteredList = new ArrayList<>();
        for (Sellers item : list_sellers) {
            if (item.getDealership().toLowerCase().contains(text.toLowerCase())) {
                filteredList.add(item);
            }
        }
        viewHolderSellers.filterList(filteredList);
    }

    public void showDialog(Activity activity , ArrayList<Vehicles> arrayList){

        dialog = new Dialog(activity,R.style.CustomAlertDialogx);
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.dialog_recycler);
        RecyclerView recyclerView = dialog.findViewById(R.id.recycler);
        AdapterBookmarks adapterRe = new AdapterBookmarks(activity,arrayList);
        recyclerView.setAdapter(adapterRe);
        recyclerView.setLayoutManager(new LinearLayoutManager(activity, LinearLayoutManager.VERTICAL, false));
        dialog.setOnKeyListener(new Dialog.OnKeyListener() {
            @Override
            public boolean onKey(DialogInterface dialogInterface, int keycode, KeyEvent keyEvent) {
                if (keycode == KeyEvent.KEYCODE_BACK) {
                    dialogInterface.dismiss();
                }
                return false;
            }
        });

        dialog.show();
    }



    public void fetch_bookmarks(){
       DatabaseReference db_ref_bookmarks=FirebaseDatabase.getInstance().getReference().child("Users");
        db_ref_bookmarks.child(firebaseAuth.getUid()).child("Bookmarks").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                list_bookmarks.clear();
                for (DataSnapshot postSnapshot : snapshot.getChildren()) {

                    String key=postSnapshot.getKey();
                    String vehicleName = postSnapshot.child("vehicleName").getValue(String.class);
                    String vehicleCategory = postSnapshot.child("vehicleCategory").getValue(String.class);
                    String mileage = postSnapshot.child("mileage").getValue(String.class);
                    String vehicleReg = postSnapshot.child("vehicleReg").getValue(String.class);
                    String vehiclePrice = postSnapshot.child("vehiclePrice").getValue(String.class);
                    String vehicleSeats = postSnapshot.child("vehicleSeats").getValue(String.class);
                    String vehicleType = postSnapshot.child("vehicleType").getValue(String.class);
                    String fuelType = postSnapshot.child("fuelType").getValue(String.class);
                    String vehicleManufacturer = postSnapshot.child("vehicleManufacturer").getValue(String.class);
                    String vehicleIcon = postSnapshot.child("vehicleIcon").getValue(String.class);

                    list_bookmarks.add(new Vehicles(key,vehicleName,"",vehicleCategory,mileage,vehicleReg,vehiclePrice,vehicleSeats,vehicleType,fuelType,vehicleManufacturer,vehicleIcon,"",""));

                }
                if(list_bookmarks.size()>0){

                    showDialog(UserActivity.this,list_bookmarks);

                }
                else{

                    Toast.makeText(UserActivity.this,"Something went wrong",Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }



}