package com.example.autohausv2;


import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;


public class ViewHolderVehiclesSeller extends RecyclerView.Adapter<ViewHolderVehiclesSeller.sellers> {

    Context context;
    ArrayList<Vehicles> list_vehicles;
    DatabaseReference databaseReference;

    public ViewHolderVehiclesSeller(Context c, ArrayList<Vehicles> l) {
        context = c;
        list_vehicles = l;
        databaseReference= FirebaseDatabase.getInstance().getReference().child("Users");
    }


    @NonNull
    @Override
    public sellers onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new sellers(LayoutInflater.from(context).inflate(R.layout.list_layout_vehicles, parent, false));
    }


    @SuppressLint("RecyclerView")
    @Override
    public void onBindViewHolder(@NonNull sellers holder, final int position) {

        holder.txt_name.setText(list_vehicles.get(position).getName());
        holder.txt_category.setText(list_vehicles.get(position).getCategory());
        holder.txt_manufacturer.setText(list_vehicles.get(position).getManufacturer());
        holder.txt_price.setText("£"+list_vehicles.get(position).getPrice());



        if(list_vehicles.get(position).getIcon().equals("")){

        }
        else{
            Picasso.get().load(list_vehicles.get(position).getIcon()).into(holder.image);
        }

        holder.cardView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {

                new AlertDialog.Builder(context)
                        .setTitle(R.string.app_name)
                        .setMessage("Are you sure you want to delete this entry?")
                        .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                Controller.showLoader(context,"Please wait . . . ");
                                databaseReference= databaseReference.child(list_vehicles.get(position).getUid()).child("Vehicles").child(list_vehicles.get(position).getKey());

                                databaseReference.removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if(task.isSuccessful()){

                                            notifyDataSetChanged();
                                            Controller.stopLoader();
                                        }
                                    }
                                });

                            }
                        }).setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                            }
                        })
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .show();

                return false;
            }
        });

        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                Intent intent = new Intent(context, AddVehicleActivity.class);
                intent.putExtra("key", list_vehicles.get(position).getKey());
                intent.putExtra("uid", list_vehicles.get(position).getUid());
                intent.putExtra("name", list_vehicles.get(position).getName());
                intent.putExtra("description", list_vehicles.get(position).getDescription());
                intent.putExtra("category", list_vehicles.get(position).getCategory());
                intent.putExtra("manufecturer", list_vehicles.get(position).getManufacturer());
                intent.putExtra("price", list_vehicles.get(position).getPrice());
                intent.putExtra("mileage", list_vehicles.get(position).getMileage());
                intent.putExtra("seats", list_vehicles.get(position).getSeats());
                intent.putExtra("reg", list_vehicles.get(position).getReg());
                intent.putExtra("ftype", list_vehicles.get(position).getFtype());
                intent.putExtra("vtype", list_vehicles.get(position).getVtype());
                intent.putExtra("icon", list_vehicles.get(position).getIcon());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return list_vehicles.size();
    }

    class sellers extends RecyclerView.ViewHolder{

        TextView txt_name,txt_category,txt_manufacturer,txt_price;
        ImageView image;
        CardView cardView;

        public sellers(View itemView){
            super(itemView);
            txt_name  = (TextView) itemView.findViewById(R.id.txt_name);
            txt_category  = (TextView) itemView.findViewById(R.id.txt_category);
            txt_manufacturer  = (TextView) itemView.findViewById(R.id.txt_manufacturer);
            txt_price  = (TextView) itemView.findViewById(R.id.txt_price);
            image=(ImageView)itemView.findViewById(R.id.image_vehicle);
            cardView = (CardView)itemView.findViewById(R.id.cardview);
        }
    }

    public void filterList(ArrayList<Vehicles> filteredList) {
        list_vehicles = filteredList;
        notifyDataSetChanged();
    }
}


