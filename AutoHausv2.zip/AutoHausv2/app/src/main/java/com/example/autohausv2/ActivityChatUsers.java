package com.example.autohausv2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class ActivityChatUsers extends AppCompatActivity {
    private RecyclerView recyclerView;
    private UsersAdapter adapter;
    private ArrayList<Users> chats=new ArrayList<>();
    private LinearLayoutManager mLayoutManager;
    private FirebaseAuth firebaseAuth;
    private DatabaseReference chatsReference;
    private ValueEventListener valueEventListenerChats;
    private ImageView backArrow;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_users);
        firebaseAuth=FirebaseAuth.getInstance();
        chatsReference= FirebaseDatabase.getInstance().getReference().child("chats");
        backArrow = findViewById(R.id.backArrow);
        backArrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        recyclerView = findViewById(R.id.recyclerview);
        mLayoutManager = new LinearLayoutManager(ActivityChatUsers.this);
        recyclerView.setLayoutManager(mLayoutManager);

        adapter = new UsersAdapter(ActivityChatUsers.this, chats);
        recyclerView.setAdapter(adapter);
        valueEventListenerChats = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                chats.clear();
                for (DataSnapshot data : dataSnapshot.getChildren()) {
                    Users users = data.getValue(Users.class);
                    chats.add(users);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        };


    }

    @Override
    public void onStart() {
        super.onStart();
        String loggedUserId = firebaseAuth.getUid();
        chatsReference.child(loggedUserId).addValueEventListener(valueEventListenerChats);
    }

    @Override
    public void onStop() {
        super.onStop();
        chatsReference.removeEventListener(valueEventListenerChats);
    }

}