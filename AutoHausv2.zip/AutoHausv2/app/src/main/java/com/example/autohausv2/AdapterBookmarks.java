package com.example.autohausv2;

import android.annotation.SuppressLint;
import android.content.Context;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;


public class AdapterBookmarks extends RecyclerView.Adapter<AdapterBookmarks.MyViewHolder> {

    private LayoutInflater inflater;
    private ArrayList<Vehicles> list_vehicles;
    Context context;

    public AdapterBookmarks(Context ctx, ArrayList<Vehicles> arrayList){
        inflater = LayoutInflater.from(ctx);
        this.context=ctx;
        this.list_vehicles = arrayList;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = inflater.inflate(R.layout.list_layout_vehicles, parent, false);
        MyViewHolder holder = new MyViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, @SuppressLint("RecyclerView") int position) {

        holder.txt_name.setText(list_vehicles.get(position).getName());
        holder.txt_category.setText(list_vehicles.get(position).getCategory());
        holder.txt_manufacturer.setText(list_vehicles.get(position).getManufacturer());
        holder.txt_price.setText(list_vehicles.get(position).getPrice());



        if(list_vehicles.get(position).getIcon().equals("")){

        }
        else{
            Picasso.get().load(list_vehicles.get(position).getIcon()).into(holder.image);
        }
    }


    @Override
    public int getItemViewType(int position) {
        return position;
    }

    @Override
    public int getItemCount() {
        return list_vehicles.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder{

        TextView txt_name,txt_category,txt_manufacturer,txt_price;
        ImageView image;
        CardView cardView;


        public MyViewHolder(View itemView) {
            super(itemView);
            txt_name  = (TextView) itemView.findViewById(R.id.txt_name);
            txt_category  = (TextView) itemView.findViewById(R.id.txt_category);
            txt_manufacturer  = (TextView) itemView.findViewById(R.id.txt_manufacturer);
            txt_price  = (TextView) itemView.findViewById(R.id.txt_price);
            image=(ImageView)itemView.findViewById(R.id.image_vehicle);
            cardView = (CardView)itemView.findViewById(R.id.cardview);

        }

    }
}

