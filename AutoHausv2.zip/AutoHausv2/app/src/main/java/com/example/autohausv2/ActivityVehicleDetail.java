package com.example.autohausv2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.util.HashMap;

public class ActivityVehicleDetail extends AppCompatActivity {

    Button btn_chat,btn_back;
    TextView txt_name,txt_desc,txt_category,txt_manufecturer,txt_price,txt_mileage,txt_seats,txt_reg,txt_ftype,txt_vtype;
    ImageView image_vehicle,btn_bookmark;
    FirebaseAuth firebaseAuth;
    private ProgressDialog progressDialog;
    private String vehicle_icon,key,uid,bookmark;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vehicle_detail);
        firebaseAuth=FirebaseAuth.getInstance();
        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("please wait");
        progressDialog.setCanceledOnTouchOutside(false);
        txt_name=findViewById(R.id.txt_name);
        txt_desc=findViewById(R.id.txt_desc);
        txt_category=findViewById(R.id.txt_category);
        txt_manufecturer=findViewById(R.id.txt_manufacturer);
        txt_price=findViewById(R.id.txt_price);
        txt_mileage=findViewById(R.id.txt_mileage);
        txt_seats=findViewById(R.id.txt_seats);
        txt_reg=findViewById(R.id.txt_reg);
        txt_ftype=findViewById(R.id.txt_ftype);
        txt_vtype=findViewById(R.id.txt_vtype);
        image_vehicle=findViewById(R.id.image_vehicle);
        btn_bookmark=findViewById(R.id.btn_bookmark);


        btn_bookmark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (bookmark.equals("liked"))
                {
                remove_bookmark(key);
                }
                else
                {
                    add_bookmark(key);
                }

            }
        });
        btn_back=findViewById(R.id.btn_back);
        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        btn_chat=findViewById(R.id.btn_chat);
        btn_chat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ActivityVehicleDetail.this, ChatActivity.class);
                intent.putExtra("uid", uid);
                startActivity(intent);
            }
        });

        Bundle extras = getIntent().getExtras();
        if(extras != null){
          txt_name.setText("VEHICLE NAME: "+extras.getString("name"));
          txt_desc.setText("VEHICLE DESCRIPTION: "+extras.getString("vehicleDescription"));
            txt_category.setText("VEHICLE CATEGORY: "+extras.getString("category"));
            txt_manufecturer.setText("MANUFACTURER: "+extras.getString("manufecturer"));
            txt_price.setText("PRICE: £"+extras.getString("price"));
            txt_mileage.setText("MILEAGE: "+extras.getString("mileage"));
            txt_seats.setText("VEHICLE SEATS: "+extras.getString("seats"));
            txt_reg.setText("VEHICLE REGISTRATION: "+extras.getString("reg"));
            txt_ftype.setText("FUEL TYPE: "+extras.getString("ftype"));
            txt_vtype.setText("GEARBOX TYPE: "+extras.getString("vtype"));
            key=extras.getString("key");
            uid=extras.getString("uid");
            bookmark=extras.getString("bookmark");
            if(bookmark.equals("true")){

                btn_bookmark.setImageResource(R.drawable.like_filled_heart);
                bookmark="liked";

            }
            else{

                btn_bookmark.setImageResource(R.drawable.like_unfilled_heart);
                bookmark="unliked";

            }
            vehicle_icon=extras.getString("icon");
            if(vehicle_icon.equals("")){

            }
            else{
                Picasso.get().load(vehicle_icon).into(image_vehicle);
            }



        }

    }

    private void remove_bookmark(String key){
        progressDialog.setMessage("Removing bookmark . . .");
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Users");
        reference.child(firebaseAuth.getUid()).child("Bookmarks").child(key).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()){
                    btn_bookmark.setImageResource(R.drawable.like_unfilled_heart);
                    bookmark="unliked";
                    Toast.makeText(ActivityVehicleDetail.this,"Bookmark removed",Toast.LENGTH_LONG).show();

                }
            }
        });
    }


    private void add_bookmark(String key) {
        progressDialog.setMessage("Adding bookmark . . .");

            HashMap<String, Object> hashMap = new HashMap<>();
            hashMap.put("vehicleName", "" + txt_name.getText().toString());
            hashMap.put("vehicleDescription", "" + txt_desc.getText().toString());
            hashMap.put("vehicleCategory", "" + txt_category.getText().toString());
            hashMap.put("vehicleManufacturer", "" + txt_manufecturer.getText().toString());
            hashMap.put("vehiclePrice", "" + txt_price.getText().toString());
            hashMap.put("mileage", "" + txt_mileage.getText().toString());
            hashMap.put("vehicleSeats", "" + txt_seats.getText().toString());
            hashMap.put("vehicleReg", "" + txt_reg.getText().toString());
            hashMap.put("fuelType", "" + txt_ftype.getText().toString());
            hashMap.put("vehicleType", "" + txt_vtype.getText().toString());
            hashMap.put("vehicleIcon", "" + vehicle_icon);

            DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Users");
            reference.child(firebaseAuth.getUid()).child("Bookmarks").child(key).setValue(hashMap)
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            btn_bookmark.setImageResource(R.drawable.like_filled_heart);
                            bookmark="liked";
                            Toast.makeText(ActivityVehicleDetail.this,"Vehicle Added to bookmark",Toast.LENGTH_LONG).show();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            progressDialog.dismiss();

                        }
                    });
    }
}